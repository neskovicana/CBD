package com.rzk.projekat.services;

import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rzk.projekat.errors.IdNotFoundException;
import com.rzk.projekat.model.Owner;
import com.rzk.projekat.model.Pet;
import com.rzk.projekat.proxy.OwnerProxy;
import com.rzk.projekat.repositories.PetRepository;

@Service
public class PetService {

	@Autowired
	private PetRepository pr;

	@Autowired
	private OwnerProxy op;

	public List<Pet> getPets() {
		return pr.findAll();
	}

	public Pet addPet(Pet p) {
		return pr.save(p);
	}

	public Pet editPet(Pet newPet, Integer id) {
		if (pr.findById(id).isEmpty()) {
			return pr.save(newPet);
		}
		Pet existingPet = pr.findById(id).get();

		existingPet.setName(newPet.getName());
		existingPet.setSpecies(newPet.getSpecies());
		existingPet.setGender(newPet.getGender());
		existingPet.setBirthdate(newPet.getBirthdate());
		existingPet.setOwner(newPet.getOwner());
		existingPet.setAppointments(newPet.getAppointments());
		existingPet.setMedicalhistories(newPet.getMedicalhistories());

		return pr.save(existingPet);
	}

	public void deletePet(Integer id) {
		if (pr.findById(id).isEmpty())
			throw new IdNotFoundException("There is no pet with given id: " + id);
		pr.deleteById(id);
	}
	
	public Pet getPetById(Integer id) {
		if (pr.findById(id).isEmpty())
			throw new IdNotFoundException("There is no pet with given id: " + id);
		return pr.findById(id).get();
	}

	public List<Pet> addPetForOwner(Integer idO, Pet p) {
		try {
			Owner o = op.getOwnerById(idO);
			List<Pet> pets = o.getPets();

			p.setOwner(o);
			pr.save(p);

			pets.add(p);
			o.setPets(pets);

			return pets;
		} catch (Exception e) {
			System.err.println("There is no owner for given id: " + idO);
			return Collections.emptyList();
		}
	}

}

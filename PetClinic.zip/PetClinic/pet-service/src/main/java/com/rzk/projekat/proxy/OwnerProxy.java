package com.rzk.projekat.proxy;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.rzk.projekat.model.Owner;

@FeignClient(name="owner-service", url="http://localhost:8000")
public interface OwnerProxy {

	@GetMapping("/owners/get-by-id/{id}")
	public Owner getOwnerById(@PathVariable Integer id);
	
}

package com.rzk.projekat.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.rzk.projekat.model.Pet;
import com.rzk.projekat.services.PetService;

import jakarta.validation.Valid;

@RestController
public class PetController {

	@Autowired
	private PetService ps;
	
	@GetMapping("/pets")
	public List<Pet> getPets() {
		return ps.getPets();
	}
	
	@PostMapping("/pets")
	public Pet addPet(@RequestBody @Valid Pet p) {
		return ps.addPet(p);
	}
	
	@PutMapping("/pets/{id}")
	public Pet updatePet(@RequestBody @Valid Pet p, @PathVariable int id) {
		return ps.editPet(p, id);
	}
	
	@DeleteMapping("/pets/{id}")
	public void deletePet(@PathVariable int id) {
		ps.deletePet(id);
	}
	
	@GetMapping("/pets/get-by-id/{id}")
	public Pet getById(@PathVariable int id) {
		return ps.getPetById(id);
	}
	
	@PostMapping("/pets/add-pet-for-owner/{id}")
	public List<Pet> addPetForOwner(@PathVariable int id, @RequestBody @Valid Pet p) {
		return ps.addPetForOwner(id, p);
	}
	
}

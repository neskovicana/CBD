package com.rzk.projekat.model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;


/**
 * The persistent class for the pet database table.
 * 
 */
@Entity
@NamedQuery(name="Pet.findAll", query="SELECT p FROM Pet p")
public class Pet implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int idPet;

	@NotNull(message="Birthdate must be provided")
	@Temporal(TemporalType.DATE)
	private Date birthdate;

	@Size(min=1, max=1, message="Gender can be M or F")
	private String gender;

	@Size(min=1, message="Name has to have at least one letter")
	private String name;

	@NotNull(message="Species must be provided")
	private String species;

	//bi-directional many-to-one association to Appointment
	@OneToMany(mappedBy="pet", cascade=CascadeType.REMOVE)
	private List<Appointment> appointments;

	//bi-directional many-to-one association to Medicalhistory
	@OneToMany(mappedBy="pet", cascade=CascadeType.REMOVE)
	private List<Medicalhistory> medicalhistories;

	//bi-directional many-to-one association to Owner
	@ManyToOne
	@JoinColumn(name="idOwner")
	@JsonIgnore
	private Owner owner;

	public Pet() {
	}

	public int getIdPet() {
		return this.idPet;
	}

	public void setIdPet(int idPet) {
		this.idPet = idPet;
	}

	public Date getBirthdate() {
		return this.birthdate;
	}

	public void setBirthdate(Date birthdate) {
		this.birthdate = birthdate;
	}

	public String getGender() {
		return this.gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSpecies() {
		return this.species;
	}

	public void setSpecies(String species) {
		this.species = species;
	}

	public List<Appointment> getAppointments() {
		return this.appointments;
	}

	public void setAppointments(List<Appointment> appointments) {
		this.appointments = appointments;
	}

	public Appointment addAppointment(Appointment appointment) {
		getAppointments().add(appointment);
		appointment.setPet(this);

		return appointment;
	}

	public Appointment removeAppointment(Appointment appointment) {
		getAppointments().remove(appointment);
		appointment.setPet(null);

		return appointment;
	}

	public List<Medicalhistory> getMedicalhistories() {
		return this.medicalhistories;
	}

	public void setMedicalhistories(List<Medicalhistory> medicalhistories) {
		this.medicalhistories = medicalhistories;
	}

	public Medicalhistory addMedicalhistory(Medicalhistory medicalhistory) {
		getMedicalhistories().add(medicalhistory);
		medicalhistory.setPet(this);

		return medicalhistory;
	}

	public Medicalhistory removeMedicalhistory(Medicalhistory medicalhistory) {
		getMedicalhistories().remove(medicalhistory);
		medicalhistory.setPet(null);

		return medicalhistory;
	}

	public Owner getOwner() {
		return this.owner;
	}

	public void setOwner(Owner owner) {
		this.owner = owner;
	}

}
package com.rzk.projekat.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.*;
import jakarta.validation.constraints.Size;


/**
 * The persistent class for the medicalhistory database table.
 * 
 */
@Entity
@NamedQuery(name="Medicalhistory.findAll", query="SELECT m FROM Medicalhistory m")
public class Medicalhistory implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int idMedicalHistory;

	@Size(max=255, message="Diagnosis size can't be larger than 255")
	private String diagnosis;

	@Size(max=255, message="Treatment size can't be larger than 255")
	private String treatment;

	//bi-directional many-to-one association to Pet
	@ManyToOne
	@JoinColumn(name="idPet")
	@JsonIgnore
	private Pet pet;

	public Medicalhistory() {
	}

	public int getIdMedicalHistory() {
		return this.idMedicalHistory;
	}

	public void setIdMedicalHistory(int idMedicalHistory) {
		this.idMedicalHistory = idMedicalHistory;
	}

	public String getDiagnosis() {
		return this.diagnosis;
	}

	public void setDiagnosis(String diagnosis) {
		this.diagnosis = diagnosis;
	}

	public String getTreatment() {
		return this.treatment;
	}

	public void setTreatment(String treatment) {
		this.treatment = treatment;
	}

	public Pet getPet() {
		return this.pet;
	}

	public void setPet(Pet pet) {
		this.pet = pet;
	}

}
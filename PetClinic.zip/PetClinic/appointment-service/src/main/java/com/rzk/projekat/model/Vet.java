package com.rzk.projekat.model;

import java.io.Serializable;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import java.util.List;


/**
 * The persistent class for the vet database table.
 * 
 */
@Entity
@NamedQuery(name="Vet.findAll", query="SELECT v FROM Vet v")
public class Vet implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int idVet;

	@Size(min=2, message="First name has to have at least two letters")
	private String firstName;

	@Size(min=2, message="Last name has to have at least two letters")
	private String lastName;

	@NotNull(message="Phone number must be provided")
	private String phoneNumber;

	@NotNull(message="Specialization must be provided")
	private String specialization;

	//bi-directional many-to-one association to Appointment
	@OneToMany(mappedBy="vet", cascade=CascadeType.REMOVE)
	private List<Appointment> appointments;

	public Vet() {
	}

	public int getIdVet() {
		return this.idVet;
	}

	public void setIdVet(int idVet) {
		this.idVet = idVet;
	}

	public String getFirstName() {
		return this.firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return this.lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getPhoneNumber() {
		return this.phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getSpecialization() {
		return this.specialization;
	}

	public void setSpecialization(String specialization) {
		this.specialization = specialization;
	}

	public List<Appointment> getAppointments() {
		return this.appointments;
	}

	public void setAppointments(List<Appointment> appointments) {
		this.appointments = appointments;
	}

	public Appointment addAppointment(Appointment appointment) {
		getAppointments().add(appointment);
		appointment.setVet(this);

		return appointment;
	}

	public Appointment removeAppointment(Appointment appointment) {
		getAppointments().remove(appointment);
		appointment.setVet(null);

		return appointment;
	}

}
package com.rzk.projekat.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.rzk.projekat.model.Pet;

public interface PetRepository extends JpaRepository<Pet, Integer> {

}

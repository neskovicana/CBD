package com.rzk.projekat.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.rzk.projekat.model.Vet;

public interface VetRepository extends JpaRepository<Vet, Integer>{

}

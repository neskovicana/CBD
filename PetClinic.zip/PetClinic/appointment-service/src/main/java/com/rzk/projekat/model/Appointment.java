package com.rzk.projekat.model;

import java.io.Serializable;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnore;


/**
 * The persistent class for the appointment database table.
 * 
 */
@Entity
@NamedQuery(name="Appointment.findAll", query="SELECT a FROM Appointment a")
public class Appointment implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int idAppointment;

	@NotNull(message="Date of appointment must be provided")
	@Temporal(TemporalType.DATE)
	private Date date;

	@Size(max=255, message="Reason for appointment size can't be larger than 255")
	private String reason;

	//bi-directional many-to-one association to Pet
	@ManyToOne
	@JoinColumn(name="idPet")
	@JsonIgnore
	private Pet pet;

	//bi-directional many-to-one association to Vet
	@ManyToOne
	@JoinColumn(name="idVet")
	@JsonIgnore
	private Vet vet;

	public Appointment() {
	}

	public int getIdAppointment() {
		return this.idAppointment;
	}

	public void setIdAppointment(int idAppointment) {
		this.idAppointment = idAppointment;
	}

	public Date getDate() {
		return this.date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public String getReason() {
		return this.reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public Pet getPet() {
		return this.pet;
	}

	public void setPet(Pet pet) {
		this.pet = pet;
	}

	public Vet getVet() {
		return this.vet;
	}

	public void setVet(Vet vet) {
		this.vet = vet;
	}

}
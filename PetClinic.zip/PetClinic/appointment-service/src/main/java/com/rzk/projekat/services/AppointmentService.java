package com.rzk.projekat.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rzk.projekat.errors.IdNotFoundException;
import com.rzk.projekat.model.Appointment;
import com.rzk.projekat.model.Pet;
import com.rzk.projekat.model.Vet;
import com.rzk.projekat.proxy.PetProxy;
import com.rzk.projekat.proxy.VetProxy;
import com.rzk.projekat.repositories.AppointmentRepository;

@Service
public class AppointmentService {

	@Autowired
	private AppointmentRepository ar;
	
	@Autowired
	private VetProxy vp;
	
	@Autowired
	private PetProxy pp;
	
	public List<Appointment> getAppointments() {
		return ar.findAll();
	}
	
	public Appointment addAppointment(Integer idPet, Integer idVet, Appointment a) {
		try {
			Pet p = pp.getPetById(idPet);
			Vet v = vp.getVetById(idVet);
			a.setPet(p);
			a.setVet(v);
			return ar.save(a);
		} catch (Exception e) {
			System.err.println("Id not found.");
			return null;
		}
	}
	
	public Appointment editAppointment(Appointment newA, Integer id) {
		if (ar.findById(id).isEmpty()) {
			return ar.save(newA);
		}
		
		Appointment existingAppointment = ar.findById(id).get();
		
		existingAppointment.setDate(newA.getDate());
		existingAppointment.setReason(newA.getReason());
		existingAppointment.setPet(newA.getPet());
		existingAppointment.setVet(newA.getVet());
		
		return ar.save(existingAppointment);
	}
	
	public void deleteAppointment(Integer id) {
		if (ar.findById(id).isEmpty())
			throw new IdNotFoundException("There is no appointment with id: " + id);
		ar.deleteById(id);
	}
	
	public Appointment getAppointmentById(Integer id) {
		if (ar.findById(id).isEmpty())
			throw new IdNotFoundException("There is no appointment with id: " + id);
		return ar.findById(id).get();
	}
	
	public Vet getVetForAppointment(Integer idA) {
		if (ar.findById(idA).isEmpty())
			throw new IdNotFoundException("There is no appointment with id: " + idA);
		return ar.findById(idA).get().getVet();
	}
}

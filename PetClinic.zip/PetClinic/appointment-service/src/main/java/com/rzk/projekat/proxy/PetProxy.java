package com.rzk.projekat.proxy;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.rzk.projekat.model.Pet;

@FeignClient(name="pet-service", url="http://localhost:8001")
public interface PetProxy {
	
	@GetMapping("/pets/get-by-id/{id}")
	public Pet getPetById(@PathVariable Integer id);

}

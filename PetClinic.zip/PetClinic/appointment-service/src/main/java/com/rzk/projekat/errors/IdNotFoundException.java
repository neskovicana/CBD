package com.rzk.projekat.errors;

public class IdNotFoundException extends RuntimeException {
	
	private static final long serialVersionUID = -8618442220539600225L;

	public IdNotFoundException(String msg) {
		super(msg);
	}
	
}

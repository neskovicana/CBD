package com.rzk.projekat.proxy;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.rzk.projekat.model.Vet;

@FeignClient(name="vet-service", url="http://localhost:8002")
public interface VetProxy {

	@GetMapping("/vets/get-by-id/{id}")
	public Vet getVetById(@PathVariable int id);
	
}

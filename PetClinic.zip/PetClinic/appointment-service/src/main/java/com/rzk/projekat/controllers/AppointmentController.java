package com.rzk.projekat.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.rzk.projekat.model.Appointment;
import com.rzk.projekat.model.Vet;
import com.rzk.projekat.services.AppointmentService;

import jakarta.validation.Valid;

@RestController
public class AppointmentController {
	
	@Autowired
	private AppointmentService as;
	
	@GetMapping("/appointments")
	public List<Appointment> getAppointments() {
		return as.getAppointments();
	}
	
	@PostMapping("/appointments/{petId}/{vetId}")
	public Appointment addAppointment(@PathVariable int petId, @PathVariable int vetId, @RequestBody @Valid Appointment a) {
		return as.addAppointment(petId, vetId, a);
	}
	
	@PutMapping("/appointments/{id}")
	public Appointment updateAppointment(@PathVariable int id, @RequestBody @Valid Appointment a) {
		return as.editAppointment(a, id);
	}
	
	@DeleteMapping("/appointments/{id}")
	public void deleteAppointment(@PathVariable int id) {
		as.deleteAppointment(id);
	}
	
	@GetMapping("/appointment/get-by-id/{id}")
	public Appointment getById(@PathVariable int id) {
		return as.getAppointmentById(id);
	}
	
	@GetMapping("/appointments/vet-for-appointment/{idA}")
	public Vet getVetForAppointment(@PathVariable int idA) {
		return as.getVetForAppointment(idA);
	}

}

package com.rzk.projekat.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.rzk.projekat.model.Appointment;

public interface AppointmentRepository extends JpaRepository<Appointment, Integer> {

}

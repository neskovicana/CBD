package com.rzk.projekat.config;

import java.util.function.Function;

import org.springframework.cloud.gateway.route.Route;
import org.springframework.cloud.gateway.route.RouteLocator;
import org.springframework.cloud.gateway.route.builder.Buildable;
import org.springframework.cloud.gateway.route.builder.PredicateSpec;
import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ApiGatewayConfiguration {

	@Bean
	public RouteLocator gatewayRouter(RouteLocatorBuilder builder) {
		Function<PredicateSpec, Buildable<Route>> routeFunction = 
				p -> p.path("/get")
				.filters(f->f.addRequestHeader("MyHeader", "MyURI").addRequestParameter("myParam", "myValue"))
				.uri("http://httpbin.org:80");
		
		return builder.routes()
				.route(routeFunction)
				.route(p->p.path("/pets**").uri("lb://pet-service"))
				.route(p->p.path("/get-pets/**")
					.filters(f->f.rewritePath("/get-pets", "/pets")).uri("lb://pet-service"))
				.route(routeFunction)
				.route(p->p.path("/owners**").uri("lb://owner-service"))
				.route(p->p.path("/get-owners/**")
					.filters(f->f.rewritePath("/get-owners", "/owners")).uri("lb://owner-service"))
				.route(routeFunction)
				.route(p->p.path("/vets**").uri("lb://vet-service"))
				.route(p->p.path("/get-vets/**")
					.filters(f->f.rewritePath("/get-vets", "/vets")).uri("lb://vet-service"))
				.route(routeFunction)
				.route(p->p.path("/medicalhistories**").uri("lb://medicalhistory-service"))
				.route(p->p.path("/get-medicalhistories/**")
					.filters(f->f.rewritePath("/get-medicalhistories", "/medicalhistories")).uri("lb://medicalhistory-service"))
				.route(routeFunction)
				.route(p->p.path("/appointments**").uri("lb://appointment-service"))
				.route(p->p.path("/get-appointments/**")
					.filters(f->f.rewritePath("/get-appointments", "/appointments")).uri("lb://appointment-service"))
				.build();
	}
	
}

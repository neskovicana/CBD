package com.rzk.projekat.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.rzk.projekat.model.Appointment;
import com.rzk.projekat.model.Vet;
import com.rzk.projekat.services.VetService;

import jakarta.validation.Valid;

@RestController
public class VetController {
	
	@Autowired
	private VetService vs;
	
	@GetMapping("/vets")
	public List<Vet> getVets() {
		return vs.getVets();
	}
	
	@PostMapping("/vets")
	public Vet addVet(@RequestBody @Valid Vet v) {
		return vs.addVet(v);
	}
	
	@PutMapping("/vets/{id}")
	public Vet updateVet(@RequestBody @Valid Vet v, @PathVariable int id) {
		return vs.editVet(v, id);
	}
	
	@DeleteMapping("/vets/{id}")
	public void deleteVet(@PathVariable int id) {
		vs.deleteVet(id);
	}
	
	@GetMapping("/vets/get-by-id/{id}")
	public Vet getById(@PathVariable int id) {
		return vs.getVetById(id);
	}
	
	@GetMapping("/vets/get-appointments/{id}")
	public List<Appointment> getAllAppointments(@PathVariable int id) {
		return vs.getAllAppointments(id);
	}
}

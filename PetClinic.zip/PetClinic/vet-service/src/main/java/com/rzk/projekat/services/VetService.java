package com.rzk.projekat.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rzk.projekat.errors.IdNotFoundException;
import com.rzk.projekat.model.Appointment;
import com.rzk.projekat.model.Vet;
import com.rzk.projekat.repositories.VetRepository;

@Service
public class VetService {

	@Autowired
	private VetRepository vr;
	
	public List<Vet> getVets() {
		return vr.findAll();
	}
	
	public Vet addVet(Vet v) {
		return vr.save(v);
	}
	
	public Vet editVet(Vet newVet, Integer id) {
		if (vr.findById(id).isEmpty()) {
			return vr.save(newVet);
		}
		
		Vet existingVet = vr.findById(id).get();
		
		existingVet.setFirstName(newVet.getFirstName());
		existingVet.setLastName(newVet.getLastName());
		existingVet.setSpecialization(newVet.getSpecialization());
		existingVet.setPhoneNumber(newVet.getPhoneNumber());
		existingVet.setAppointments(newVet.getAppointments());
		
		return vr.save(existingVet);
	}
	
	public void deleteVet(Integer id) {
		if (vr.findById(id).isEmpty())
			throw new IdNotFoundException("There is no vet with given id: " + id);
		vr.deleteById(id);
	}
	
	public Vet getVetById(Integer id) {
		if (vr.findById(id).isEmpty())
			throw new IdNotFoundException("There is no vet with given id: " + id);
		return vr.findById(id).get();
	}
	
	public List<Appointment> getAllAppointments(Integer id) {
		if (vr.findById(id).isEmpty())
			throw new IdNotFoundException("There is no vet with given id: " + id);
		return vr.findById(id).get().getAppointments();
	}
	
}

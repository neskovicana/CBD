package com.rzk.projekat.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rzk.projekat.errors.IdNotFoundException;
import com.rzk.projekat.model.Medicalhistory;
import com.rzk.projekat.model.Pet;
import com.rzk.projekat.proxy.PetProxy;
import com.rzk.projekat.repositories.MedicalHistoryRepository;

@Service
public class MedicalHistoryService {

	@Autowired
	private MedicalHistoryRepository mhr;

	@Autowired
	private PetProxy pp;

	public List<Medicalhistory> getMedicalHistories() {
		return mhr.findAll();
	}

	public Medicalhistory addMedicalHistory(Integer petId, Medicalhistory h) {
		try {
			Pet p = pp.getById(petId);
			h.setPet(p);
			p.addMedicalhistory(h);
			pp.updatePet(p, p.getIdPet());
			return mhr.save(h);
		} catch (Exception e) {
			System.err.println("There is no pet with given id");
			return null;
		}
	}

	public Medicalhistory editMedicalHistory(Medicalhistory newH, Integer id, Integer idP) {
		try {
			Pet p = pp.getById(idP);
			if (mhr.findById(id).isEmpty()) {
				newH.setPet(p);
				p.addMedicalhistory(newH);
				pp.updatePet(p, idP);
				return mhr.save(newH);
			}
			Medicalhistory existingH = mhr.findById(id).get();

			existingH.setDiagnosis(newH.getDiagnosis());
			existingH.setTreatment(newH.getTreatment());
			existingH.setPet(p);

			return mhr.save(existingH);
		} catch (Exception e) {
			System.err.println();
			return null;
		}
	}

	public void deleteMedicalHistory(Integer id) {
		if (mhr.findById(id).isEmpty())
			throw new IdNotFoundException("There is no medical history with given id: " + id);
		mhr.deleteById(id);
	}

	public Medicalhistory getMedicalHistoryById(Integer id) {
		if (mhr.findById(id).isEmpty())
			throw new IdNotFoundException("There is no medical history with given id: " + id);
		return mhr.findById(id).get();
	}

	public List<Medicalhistory> getPetHistory(Integer petId) {
		try {
			return pp.getById(petId).getMedicalhistories();
		} catch (Exception e) {
			System.err.println("There is no pet with given id: " + petId);
			return null;
		}
	}
}

package com.rzk.projekat.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.rzk.projekat.model.Medicalhistory;
import com.rzk.projekat.services.MedicalHistoryService;

import jakarta.validation.Valid;

@RestController
public class MedicalHistoryController {

	@Autowired
	private MedicalHistoryService mhs;
	
	@GetMapping("/medicalhistories")
	public List<Medicalhistory> getMedicalHistories() {
		return mhs.getMedicalHistories();
	}
	
	@PostMapping("/medicalhistories/{id}")
	public Medicalhistory addMedicalHistory(@PathVariable int id, @RequestBody @Valid Medicalhistory h) {
		return mhs.addMedicalHistory(id, h);
	}
	
	@PutMapping("/medicalhistories/{id}/{idP}")
	public Medicalhistory updateMedicalHistory(@RequestBody @Valid Medicalhistory h, @PathVariable int id, @PathVariable int idP) {
		return mhs.editMedicalHistory(h, id, idP);
	}
	
	@DeleteMapping("/medicalhistories/{id}")
	public void deleteMedicalHistory(@PathVariable int id) {
		mhs.deleteMedicalHistory(id);
	}
	
	@GetMapping("/medicalhistories/get-by-id/{id}")
	public Medicalhistory getById(@PathVariable int id) {
		return mhs.getMedicalHistoryById(id);
	}
	
	@GetMapping("/medicalhistories/get-pet-history/{petId}")
	public List<Medicalhistory> getPetHistory(@PathVariable int petId) {
		return mhs.getPetHistory(petId);
	}
}

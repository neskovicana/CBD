package com.rzk.projekat.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rzk.projekat.errors.IdNotFoundException;
import com.rzk.projekat.model.Owner;
import com.rzk.projekat.model.Pet;
import com.rzk.projekat.repositories.OwnerRepository;

@Service
public class OwnerService {

	@Autowired
	private OwnerRepository or;
	
	public List<Owner> getOwners() {
		return or.findAll();
	}
	
	public Owner addOwner(Owner o) {
		return or.save(o);
	}
	
	public Owner editOwner(Owner newOwner, Integer id) {
		
		if (or.findById(id).isEmpty()) {
			return or.save(newOwner);
		}
		
		Owner existingOwner = or.findById(id).get();
		
		existingOwner.setFirstName(newOwner.getFirstName());
		existingOwner.setLastName(newOwner.getLastName());
		existingOwner.setPhoneNumber(newOwner.getPhoneNumber());
		existingOwner.setPets(newOwner.getPets());
		
		return or.save(existingOwner);
	}
	
	public void deleteOwner(Integer id) {
		if (or.findById(id).isEmpty())
			throw new IdNotFoundException("There is no owner with given id: " + id);
		or.deleteById(id);
	}
	
	public List<Pet> getPets(Integer id) {
		if (or.findById(id).isEmpty())
			throw new IdNotFoundException("There is no owner with given id: " + id);
		return or.findById(id).get().getPets();
	}
	
	public Owner getOwnerById(Integer id) {
		if (or.findById(id).isEmpty())
			throw new IdNotFoundException("There is no owner with given id: " + id);
		return or.findById(id).get();
	}
	
}

package com.rzk.projekat.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.rzk.projekat.model.Owner;
import com.rzk.projekat.model.Pet;
import com.rzk.projekat.services.OwnerService;

import jakarta.validation.Valid;

@RestController
public class OwnerController {

	@Autowired
	private OwnerService os;
	
	@GetMapping("/owners")
	public List<Owner> getOwners() {
		return os.getOwners();
	}
	
	@PostMapping("/owners")
	public Owner addOwner(@RequestBody @Valid Owner o) {
		return os.addOwner(o);
	}

	@PutMapping("/owners/{id}")
	public Owner updateOwner(@RequestBody @Valid Owner o, @PathVariable int id) {
		return os.editOwner(o, id);
	}
	
	@DeleteMapping("/owners/{id}")
	public void deleteOwner(@PathVariable int id) {
		os.deleteOwner(id);
	}
	
	@GetMapping("/owners/get-pets/{id}")
	public List<Pet> getPets(@PathVariable int id) {
		return os.getPets(id);
	}
	
	@GetMapping("/owners/get-by-id/{id}")
	public Owner getOwnerById(@PathVariable int id) {
		return os.getOwnerById(id);
	}

}
